module com.example.assignment62 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.assignment62 to javafx.fxml;
    exports com.example.assignment62;
}