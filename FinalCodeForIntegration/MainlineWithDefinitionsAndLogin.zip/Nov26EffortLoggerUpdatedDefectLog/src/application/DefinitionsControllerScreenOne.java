//Authorship: Nathan Komenkul

package application;

import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class DefinitionsControllerScreenOne implements Initializable {
	private Stage stage;
	private Scene scene;
	private Parent root;
	static ObservableList<String> projectDef = FXCollections.observableArrayList();
	static ObservableList<String> lifeCycleDef = FXCollections.observableArrayList();
	
	//ListView elements
	@FXML
	private ListView<String> projectList;
	@FXML
	private ListView<String> lifeCycleList;
	
	//TextField elements for editing ListViews
	@FXML
	private TextField projectText;
	@FXML
	private TextField lifeCycleText;
	@FXML
	
	//Event of going to the main console
	public void goToConsole(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("Submission4Prototype.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	//Event of going to the defect log console
	public void goToDefectLogConsole(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("defect.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	//Event of going to the effort and defect logs
	public void goToEffortDefectLogs(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("NextScene.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	//Event of going to the effort log editor
	public void goToEffortLogEditor(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("NextScene.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	//Event of going to the effort category definitions
	public void goEffortCategories(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("DefinitionsEffortCategories.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	//Used to initialize the listviews
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		try {
			loadDefinitions(projectDef, "ProjectDefinitions.txt");
			loadDefinitions(lifeCycleDef, "LifeCycleDefinitions.txt");
		} catch (IOException e) {
			e.printStackTrace();
		}
		projectList.getItems().addAll(projectDef);
		lifeCycleList.getItems().addAll(lifeCycleDef);
	}
	
	//Method for loading definitions from a file into an array list
	public static void loadDefinitions(ObservableList<String> definitions, String fileName) throws IOException {
		FileReader fr = new FileReader(fileName);
		Scanner scanner = new Scanner(fr);
		definitions.clear();
		while (scanner.hasNextLine()) {
			definitions.add(scanner.nextLine());
		}
		scanner.close();
		fr.close();
	}
	
	//Method for writing definitions to definition text files
	public void writeDefinitions(ObservableList<String> definitions, String fileName) throws IOException {
		FileWriter fw = new FileWriter(fileName, false);
		BufferedWriter bw = new BufferedWriter(fw);
		PrintWriter outFile = new PrintWriter(bw);
		
		for (int i = 0; i < definitions.size(); i++) {
				outFile.printf("%s\n", definitions.get(i));
		}
		outFile.close();
		bw.close();
		fw.close();
	}
	
	//Utility method for adding items to a definitions list
	public void addToList(ObservableList<String> definitions, TextField input, ListView<String> list, String fileName) throws IOException {
		String newText = input.getText();
		if (newText.equals("")) {
				return;
		}
		else {
			list.getItems().add(newText);
			definitions.add(newText);
			writeDefinitions(definitions, fileName);
		}
		input.clear();
	}
	
	//Utility method for removing items from a definitions list
	public void removeFromList(ObservableList<String> definitions, TextField input, ListView<String> list, String fileName) throws IOException {
		String newText = input.getText();
		if (newText.equals("")) {
				return;
		}
		else {
			for (int i = 0; i < definitions.size(); i++) {
				if (newText.equals(definitions.get(i))) {
					list.getItems().remove(i);
					definitions.remove(i);
					break;
				}
		}
		writeDefinitions(definitions, fileName);
		}
		input.clear();
	}
	
	//Utility method for resetting a definitions list to its default values
	public void resetList(ObservableList<String> definitions, TextField input, ListView<String> list, String fileName, String defaultFileName) throws IOException {
		while (definitions.size() != 0) {
			definitions.remove(0);
			list.getItems().remove(0);
		}
		loadDefinitions(definitions, defaultFileName);
		list.getItems().addAll(definitions);
		writeDefinitions(definitions, fileName);
	}
	
	//Adding to specific definition lists
	public void addToProject(ActionEvent event) throws IOException {
		addToList(projectDef, projectText, projectList, "ProjectDefinitions.txt");
	}
	
	public void addToLifeCycle(ActionEvent event) throws IOException {
		addToList(lifeCycleDef, lifeCycleText, lifeCycleList, "LifeCycleDefinitions.txt");
	}
	
	//Removing from specific definition lists
	public void removeFromProject(ActionEvent event) throws IOException {
		removeFromList(projectDef, projectText, projectList, "ProjectDefinitions.txt");
	}
	
	public void removeFromLifeCycle(ActionEvent event) throws IOException {
		removeFromList(lifeCycleDef, lifeCycleText, lifeCycleList, "LifeCycleDefinitions.txt");
	}
	
	//Resetting specific definition lists
	public void resetProject(ActionEvent event) throws IOException {
		resetList(projectDef, projectText, projectList, "ProjectDefinitions.txt", "ProjectDefinitionsDefault.txt");
	}
	
	public void resetLifeCycle(ActionEvent event) throws IOException {
		resetList(lifeCycleDef, lifeCycleText, lifeCycleList, "LifeCycleDefinitions.txt","LifeCycleDefinitionsDefault.txt");
	}
	
}
