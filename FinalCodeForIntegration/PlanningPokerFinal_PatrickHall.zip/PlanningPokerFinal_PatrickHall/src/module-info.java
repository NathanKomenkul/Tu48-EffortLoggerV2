module PlanningPoker {
	requires javafx.controls;
	requires javafx.fxml;
	requires java.base;
	requires javafx.base;
	
	opens application to javafx.graphics, javafx.fxml;
}
