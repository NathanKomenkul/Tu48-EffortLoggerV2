package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.control.TextArea;
import javafx.scene.control.Button;
import java.nio.file.Files;
import java.nio.file.Paths;
import javafx.stage.FileChooser;
import java.io.BufferedReader;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import java.io.*;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.AnchorPane;
import javafx.util.converter.IntegerStringConverter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javafx.collections.ObservableList;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import java.util.stream.Collectors;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.Callback;
import javafx.util.StringConverter;
import javafx.scene.control.TableCell;

public class SceneController {
	
	private Stage stage;
	private Scene scene;
	private Parent root;
	
	@FXML
    private TextArea userStoryTextArea;

    @FXML
    private TextField projectNameTextField;

    @FXML
    private TextField keywordsTextField;

    @FXML
    private Button saveNextButton;
    
    @FXML
    private Button importDataButton;
    
    @FXML
    private Label projectNameLabel;
    
    @FXML
    private Label keywordsLabel;
    
    
    public class FileLine {
        private final String line;
        private final Slider slider;

        public FileLine(String line) {
            this.line = line;
            this.slider = new Slider(1, 20, 1); // Set min, max, and initial value
            
        }

        public String getLine() {
            return line;
        }
        
        public Slider getSlider() {
            return slider;
        }
    }
    
    public class FileUtility {
    	
    	//Utility method for getting information from files
    	public static void loadInformation(ObservableList<String> information, String fileName) throws IOException {
    		FileReader fr = new FileReader(fileName);
    		Scanner scanner = new Scanner(fr);
    		information.clear();
    		while (scanner.hasNextLine()) {
    			information.add(scanner.nextLine());
    		}
    		scanner.close();
    		fr.close();
    	}
    	
    	//Method for writing definitions to definition text files
    	public static void writeInformation(ObservableList<String> information, String fileName) throws IOException {
    		FileWriter fw = new FileWriter(fileName, false);
    		BufferedWriter bw = new BufferedWriter(fw);
    		PrintWriter outFile = new PrintWriter(bw);	
    		for (int i = 0; i < information.size(); i++) {
    			outFile.printf("%s\n", information.get(i));
    		}
    		outFile.close();
    		bw.close();
    		fw.close();
    	}
    }
    
    public class PlanningPokerData {
        private String userStory;
        private String projectName;
        private String keywords;

     // Default constructor
        public PlanningPokerData() {
        }

        // Constructor with parameters
        public PlanningPokerData(String userStory, String projectName, String keywords) {
            this.userStory = userStory;
            this.projectName = projectName;
            this.keywords = keywords;
        }
        
     // Getters
        public String getUserStory() {
            return userStory;
        }

        public String getProjectName() {
            return projectName;
        }

        public String getKeywords() {
            return keywords;
        }

        // Setters
        public void setUserStory(String userStory) {
            this.userStory = userStory;
        }

        public void setProjectName(String projectName) {
            this.projectName = projectName;
        }

        public void setKeywords(String keywords) {
            this.keywords = keywords;
        }
    }
    
    
    public void loadNextSceneWithData(PlanningPokerData data, ActionEvent event) {
        try {
        	FXMLLoader loader = new FXMLLoader(getClass().getResource("PlanningPokerRound1.fxml"));
            Parent root = loader.load();
            
            //PlanningPokerRound1Controller controller = loader.getController();
            //controller.initData(data);
            
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void goToRound1(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("PlanningPokerRound1.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
    }
    
    
    @FXML
    public void handleSaveNextAction(ActionEvent event) throws IOException {
    	PlanningPokerData data = new PlanningPokerData();
    	data.setUserStory(userStoryTextArea.getText());
        data.setProjectName(projectNameTextField.getText());
        data.setKeywords(keywordsTextField.getText());
        
        loadNextSceneWithData(data, event);
        /*
        // Now, we'll navigate to the Round 1 screen and pass this data to it
        FXMLLoader loader = new FXMLLoader(getClass().getResource("PlanningPokerRound1.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);
        PlanningPokerRound1Controller controller = loader.getController();
        controller.initData(userStory, projectName, keywords);
        
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
		*/
     
    }
	
    
    @FXML
    public void handleImportDataAction() {
    	try {
            ObservableList<String> information = FXCollections.observableArrayList();
            FileUtility.loadInformation(information, "C:\\Users\\patri\\Desktop\\Test1.txt");

            // Converting ObservableList to Array
            String[] historicalData = new String[information.size()];
            historicalData = information.toArray(historicalData);

            // Optional: Printing the array to verify contents
            
            for (String line : historicalData) {
                System.out.println(line);
            }
           
        } catch (IOException e) {
            e.printStackTrace();
        }
    	
    
    
    
	
    
    
    
    
}
}



