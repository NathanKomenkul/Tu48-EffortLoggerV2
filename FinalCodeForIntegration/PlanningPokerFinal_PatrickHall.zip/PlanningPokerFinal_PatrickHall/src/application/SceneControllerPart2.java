package application;

import java.util.stream.Collectors;

import application.SceneController.PlanningPokerData;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;

public class SceneControllerPart2 {
    @FXML
    private TextArea userStoryTextArea;

    @FXML
    private Label projectNameLabel;

    @FXML
    private Label keywordsLabel;
    /*
    @FXML
    private TableView<FileLine> historicalDataTable;

    @FXML
    private TableColumn<FileLine, String> lineColumn;
    
    @FXML
    private TableColumn<FileLine, Integer> estimateColumn;
	*/
    @FXML
    private TextArea estimateDisplayTextArea;

    @FXML
    private Button generateEstimateButton;

    @FXML
    private Button startDiscussionNextButton;
    
    /*
    public void populateHistoricalDataTable(List<String> lines) {
    	List<FileLine> fileLines = lines.stream().map(FileLine::new).collect(Collectors.toList());
        ObservableList<FileLine> observableLines = FXCollections.observableArrayList(fileLines);
     // Set the cell value factory for the Slider column
        lineColumn.setCellValueFactory(new PropertyValueFactory<>("line"));
        sliderColumn.setCellValueFactory(new PropertyValueFactory<>("slider"));
        historicalDataTable.setItems(observableLines);
        
        
    }*/
    public class PlanningPokerRound1Controller {
        @FXML
        private TextArea userStoryTextArea; // Assuming this TextArea is for displaying userStory

        public void initData(PlanningPokerData data) {
            userStoryTextArea.setText(data.getUserStory());
            // Handle projectName and keywords similarly if needed
        }
    }
    
    

    
}