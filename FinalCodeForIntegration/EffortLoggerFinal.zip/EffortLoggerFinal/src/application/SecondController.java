package application;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Separator;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.List;
import java.util.ArrayList;
//
public class SecondController implements Initializable {
    @FXML
    private ObservableList<Task> taskList;
    @FXML
    private ChoiceBox<String> projectBox;
    @FXML
    private ChoiceBox<String> categoryBox;
    @FXML
    private ChoiceBox<String> priorityLevel;
    
    @FXML
    private Text numTasksText;
    
    @FXML
    private Text projectNameText;
    @FXML
    private Text completionDateText;
    @FXML
    private ChoiceBox priorityBox;
    @FXML
    private Button editButton;

    @FXML
    private Text projectNameText1;
    @FXML
    private Text completionDateText1;
    @FXML
    private ChoiceBox priorityBox1;
    @FXML
    private Button editButton1;
    
    @FXML
    private ScrollPane centralScrollPane;

    //checks the source of the edit task command and send the approproate index to the update page
   
    private void editTask(Task task, int index) throws IOException {
    	writeTasksToFile();

        System.out.println("Go to main console");
        FXMLLoader firstLoader = new FXMLLoader(getClass().getResource("NewTask.fxml"));
        Parent firstView = firstLoader.load();
        NewTaskController targetController = firstLoader.getController();
  
        targetController.initializeData();
        targetController.populateTables(task, index);
        Scene scene = new Scene(firstView);
        Stage stage = (Stage) createTaskButton.getScene().getWindow();
        stage.setScene(scene);
        

    }

    @FXML
    private void editTask1(ActionEvent event) {
    	writeTasksToFile();
        System.out.println("Go to main console");
    }
    //initializes values to the scene based on values within list
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        System.out.println("Welcome!");
        
        getTasksFromFile();
        
        ObservableList<String> projects = FXCollections.observableArrayList("All Projects","Project 1", "Project 2", "Project 3");
        projectBox.setItems(projects);
        projectBox.setValue(projects.get(0));
        projectBox.valueProperty().addListener((observable, oldValue, newValue) -> {
            sortByProject(newValue);
        });
        
        ObservableList<String> categories = FXCollections.observableArrayList("All Categories","Security", "User Interface", "Authorization");
        categoryBox.setItems(categories);
        categoryBox.setValue(categories.get(0));
        categoryBox.valueProperty().addListener((observable, oldValue, newValue) -> {
            sortByCategory(newValue);
        });



    }
    //initializes values to the scene based on values within list, and sets them as invisible if the list is non existent
    public void initializeData(ObservableList<Task> list) {
        //getTasksFromFile();
        taskList = list;
        if(taskList != null) {
        	numTasksText.setText(taskList.size()+" overall tasks");
            System.out.println(taskList);
            
            VBox taskEntriesContainer = new VBox();
            taskEntriesContainer.setSpacing(10); 
            int index = 0;
            for (Task task : taskList) {
                HBox taskEntry = createTaskEntry(task, index);
                taskEntriesContainer.getChildren().add(taskEntry);
                index++;
            }
            centralScrollPane.setContent(taskEntriesContainer);
            centralScrollPane.setFitToWidth(true);
        }
        
        
        
    }
    //creates the scroll view of the list
    private HBox createTaskEntry(Task task, int index) {
        Text projectNameText = new Text(task.getTaskName());
        //projectNameText.setWrappingWidth(311.26);
        Text completionDateText = new Text("Expected Completion Date: " + task.getFinishDate());
        //completionDateText.setWrappingWidth(287.26);
        VBox nameDate = new VBox(10, projectNameText, completionDateText);
        
        ChoiceBox<String> priorityBox = new ChoiceBox<>();
        ObservableList<String> prio = FXCollections.observableArrayList("1","2","3","4","5");
        priorityBox.setItems(prio);
        priorityBox.setValue(task.getPriority()); // this statement shows default value 
        
        priorityBox.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null) {
                task.setPriority(String.valueOf(newVal)); 
            }
        });
        //checks the source of the edit button pressed
        Button editButton = new Button("Edit Task");
        editButton.setOnAction(event -> {
			try {
				editTask(task, index);
			} catch (IOException e) {
				
				e.printStackTrace();
			}
		});
        //Shows a pop-up description of the corresponding task
        Button descriptionButton = new Button("See Description");
        descriptionButton.setOnAction(event -> {
        	Alert alert = new Alert(AlertType.INFORMATION);
        	alert.setTitle("Task Description");
        	alert.setHeaderText(null); 
        	alert.setContentText(task.getDescription());
        	alert.getButtonTypes().setAll(ButtonType.OK);
        	alert.showAndWait();
        });
        final Separator separator = new Separator();

        HBox taskEntry = new HBox(10, nameDate, priorityBox, editButton, descriptionButton, separator);
        // Adjust layout positions if necessary

        return taskEntry;
    }

    @FXML
    private Button createTaskButton;
    //transisitons back to the create a new task page
    @FXML
    private void createNewTask(ActionEvent event)  throws Exception {
    	writeTasksToFile();
    	FXMLLoader firstLoader = new FXMLLoader(getClass().getResource("NewTask.fxml"));
        Parent firstView = firstLoader.load();

        NewTaskController targetController = firstLoader.getController();
        targetController.initializeData();
        
        Scene scene = new Scene(firstView);

        // Get the current stage
        Stage stage = (Stage) createTaskButton.getScene().getWindow();

        // Set the new scene (first view) on the current stage
        stage.setScene(scene);
    }

    @FXML
    private Button consoleButton;

    @FXML
    private void proceedToConsole(ActionEvent event) throws IOException {
    	FXMLLoader secondLoader = new FXMLLoader(getClass().getResource("Submission4Prototype.fxml"));
        Parent secondView = secondLoader.load();
        Scene scene = new Scene(secondView);
        scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
        Stage stage = (Stage) consoleButton.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    /*@FXML
    private Button consoleButton;
    @FXML
    private void proceedToConsole(ActionEvent event) {
    	//filler code, returns to title screen
        System.out.println("Go to main console");
        writeTasksToFile();
    }*/

    //writes the serializable array to the file
    private void writeTasksToFile() {
    	try {
            List<Task> regList = new ArrayList<>(taskList);
            FileOutputStream fileOut = new FileOutputStream("tasks.txt");
            ObjectOutputStream objectOut = new ObjectOutputStream(fileOut);
            objectOut.writeObject(regList);
            objectOut.close();
            fileOut.close();

            System.out.println("The Object was successfully written to a file");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void getTasksFromFile() {
        ObservableList<Task> newTaskList = FXCollections.observableArrayList();

        try (FileInputStream fileIn = new FileInputStream("tasks.txt");
             ObjectInputStream objectIn = new ObjectInputStream(fileIn)) {

            // Read the serialized object and cast it to a List<Task>
            List<Task> tasksFromFile = (List<Task>) objectIn.readObject();

            // Add all tasks from the deserialized list to the ObservableList
            newTaskList.addAll(tasksFromFile);
            taskList.addAll(newTaskList);
            System.out.println("Tasks have been successfully read from the file and added to the ObservableList");
        } catch (Exception e) {
            e.printStackTrace();
        }

        
    }
    //sorts displayed projects in the scroll pane by project #
    public void sortByProject(String val) {
    	//getTasksFromFile();
        
        VBox taskEntriesContainer = new VBox();
        taskEntriesContainer.setSpacing(10); 
        int index = 0;
        for (Task task : taskList) {
        	if(val.equals("All Projects") || val.equals(task.getProject())) {
        		HBox taskEntry = createTaskEntry(task, index);
                taskEntriesContainer.getChildren().add(taskEntry);
        	}
            index++;
        }
        centralScrollPane.setContent(taskEntriesContainer);
        centralScrollPane.setFitToWidth(true);
    }
    //sorts displated projects in the scrol pane by category type
    public void sortByCategory(String val) {
    	//getTasksFromFile();
        
        VBox taskEntriesContainer = new VBox();
        taskEntriesContainer.setSpacing(10); 
        int index = 0;
        for (Task task : taskList) {
        	if(val.equals("All Categories") || val.equals(task.getCategory())) {
        		HBox taskEntry = createTaskEntry(task, index);
                taskEntriesContainer.getChildren().add(taskEntry);
        	}
            index++;
        }
        centralScrollPane.setContent(taskEntriesContainer);
        centralScrollPane.setFitToWidth(true);
    }
}
