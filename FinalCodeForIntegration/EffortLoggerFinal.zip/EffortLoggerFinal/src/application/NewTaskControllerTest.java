package application;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;

import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

class NewTaskControllerTest {

    private NewTaskController controller;
    
     @BeforeEach
    void setUp() {
        controller = new NewTaskController();
        URL url = null;
        ResourceBundle resourceBundle = null;
        controller.initialize(url, resourceBundle);
    }

    @Test
    void testInitialize() {
        assertNotNull(controller.projectPicker);
        assertTrue(controller.projectPicker.getItems().contains("Project 1")); 
    }
    
	@Test
    void testCreateNewValidCategory() {
        controller.taskCategoryText = new TextField();
        controller.categoryPicker = new ChoiceBox<>();

        String newCategory = "New Category";
        controller.taskCategoryText.setText(newCategory);
        controller.createNewCategory(null); 
        assertTrue(controller.categoryPicker.getItems().contains(newCategory));
    }
    
     @Test
    void testCreateValidTask() {
        controller.taskNameBox = new TextField("Task Name");
        controller.descriptionBox = new TextField("Description");
        controller.projectPicker = new ChoiceBox<>();
        controller.categoryPicker = new ChoiceBox<>();
        controller.priorityLevel = new ChoiceBox<>();
        controller.finishDatePicker = new DatePicker(LocalDate.now());

        controller.projectPicker.setItems(FXCollections.observableArrayList("Project 1"));
        controller.categoryPicker.setItems(FXCollections.observableArrayList("Category 1"));
        controller.priorityLevel.setItems(FXCollections.observableArrayList("1"));
        
        controller.createNewTask(null); 
        assertFalse(controller.taskList.isEmpty());
        assertEquals("Task Name", controller.taskList.get(0).getTaskName());
    }
}