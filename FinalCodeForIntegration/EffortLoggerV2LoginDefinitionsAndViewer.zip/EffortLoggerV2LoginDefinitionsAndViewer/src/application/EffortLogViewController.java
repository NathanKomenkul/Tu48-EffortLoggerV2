package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.stage.Stage;

public class EffortLogViewController implements Initializable{
	private Stage stage;
	private Scene scene;
	private Parent root;
	static ObservableList<String> effortLogs = FXCollections.observableArrayList();
	
	//ListView element for effort logs
	@FXML
	private ListView<String> effortLogList;
	
	//Event of going to the main console
	public void goToConsole(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("Submission4Prototype.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
		
	//Event of going to the defect log console
	public void goToDefectLogConsole(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("defect.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	//Event of going to the effort log editor
	public void goToEffortLogEditor(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("NextScene.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
		
	//Event of going to the defect log viewer
	public void goToDefectLogViewer(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("DefectViewer.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	//Used to populate values into the effort log viewer
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		try {
			FileUtility.loadInformation(effortLogs, "ProjectDefinitions.txt");
		} catch (IOException e) {
			e.printStackTrace();
		}
		effortLogList.getItems().addAll(effortLogs);
	}
}
