//Authorship: Nathan Komenkul

package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class DefinitionsControllerScreenTwo implements Initializable {
	private Stage stage;
	private Scene scene;
	private Parent root;
	static ObservableList<String> planDef = FXCollections.observableArrayList();
	static ObservableList<String> deliverableDef = FXCollections.observableArrayList();
	static ObservableList<String> interruptionDef = FXCollections.observableArrayList();
	static ObservableList<String> defectDef = FXCollections.observableArrayList();
	static ObservableList<String> otherDef = FXCollections.observableArrayList();
	
	//ListView elements
	@FXML
	private ListView<String> planList;
	@FXML
	private ListView<String> deliverableList;
	@FXML
	private ListView<String> interruptionList;
	@FXML
	private ListView<String> defectList;
	@FXML
	private ListView<String> otherList;
	
	//TextField elements for editing ListViews
	@FXML
	private TextField planText;
	@FXML
	private TextField deliverableText;
	@FXML
	private TextField interruptionText;
	@FXML
	private TextField defectText;
	@FXML
	private TextField otherText;
	
	//Event of going to the main console
	public void goToConsole(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("Submission4Prototype.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	//Event of going to the defect log console
	public void goToDefectLogConsole(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("defect.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	//Event of going to the effort and defect logs
	public void goToEffortDefectLogs(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("EffortViewer.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	//Event of going to the effort log editor
	public void goToEffortLogEditor(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("EffortLogEditor.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	//Event of going to the project and life cycle definitions
	public void goToProjectLifeCycle(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("DefinitionsProjectLifeCycle.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	//Used to initialize the listviews
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		try {
			FileUtility.loadInformation(planDef, "PlanDefinitions.txt");
			FileUtility.loadInformation(deliverableDef, "DeliverableDefinitions.txt");
			FileUtility.loadInformation(interruptionDef, "InterruptionDefinitions.txt");
			FileUtility.loadInformation(defectDef, "DefectDefinitions.txt");
			FileUtility.loadInformation(otherDef, "OtherDefinitions.txt");
		} catch (IOException e) {
			e.printStackTrace();
		}
		planList.getItems().addAll(planDef);
		deliverableList.getItems().addAll(deliverableDef);
		interruptionList.getItems().addAll(interruptionDef);
		defectList.getItems().addAll(defectDef);
		otherList.getItems().addAll(otherDef);
	}
		
	
	//Utility method for adding items to a definitions list
	public void addToList(ObservableList<String> definitions, TextField input, ListView<String> list, String fileName) throws IOException {
		String newText = input.getText();
		if (newText.equals("")) {
				return;
		}
		else {
			list.getItems().add(newText);
			definitions.add(newText);
			FileUtility.writeInformation(definitions, fileName);
		}
		input.clear();
	}
	
	//Utility method for removing items from a definitions list
	public void removeFromList(ObservableList<String> definitions, TextField input, ListView<String> list, String fileName) throws IOException {
		String newText = input.getText();
		if (newText.equals("")) {
				return;
		}
		else {
			for (int i = 0; i < definitions.size(); i++) {
				if (newText.equals(definitions.get(i))) {
					list.getItems().remove(i);
					definitions.remove(i);
					break;
				}
		}
		FileUtility.writeInformation(definitions, fileName);
		}
		input.clear();
	}
	
	//Utility method for resetting a definitions list to its default values
	public void resetList(ObservableList<String> definitions, TextField input, ListView<String> list, String fileName, String defaultFileName) throws IOException {
		while (definitions.size() != 0) {
			definitions.remove(0);
			list.getItems().remove(0);
		}
		FileUtility.loadInformation(definitions, defaultFileName);
		list.getItems().addAll(definitions);
		FileUtility.writeInformation(definitions, fileName);
	}
	
	//------------------------------------------------------------------------------------------
	//Adding to specific definition lists
	public void addToPlan(ActionEvent event) throws IOException {
		addToList(planDef, planText, planList, "PlanDefinitions.txt");
	}
	
	public void addToDeliverable(ActionEvent event) throws IOException {
		addToList(deliverableDef, deliverableText, deliverableList, "DeliverableDefinitions.txt");
	}
	
	public void addToInterruption(ActionEvent event) throws IOException {
		addToList(interruptionDef, interruptionText, interruptionList, "InterruptionDefinitions.txt");
	}
	
	public void addToDefect(ActionEvent event) throws IOException {
		addToList(defectDef, defectText, defectList, "DefectDefinitions.txt");
	}
	
	public void addToOther(ActionEvent event) throws IOException {
		addToList(otherDef, otherText, otherList, "OtherDefinitions.txt");
	}
	
	//------------------------------------------------------------------------------------------
	//Removing from specific definition lists
	public void removeFromPlan(ActionEvent event) throws IOException {
		removeFromList(planDef, planText, planList, "PlanDefinitions.txt");
	}
	
	public void removeFromDeliverable(ActionEvent event) throws IOException {
		removeFromList(deliverableDef, deliverableText, deliverableList, "DeliverableDefinitions.txt");
	}
	
	public void removeFromInterruption(ActionEvent event) throws IOException {
		removeFromList(interruptionDef, interruptionText, interruptionList, "InterruptionDefinitions.txt");
	}
	
	public void removeFromDefect(ActionEvent event) throws IOException {
		removeFromList(defectDef, defectText, defectList, "DefectDefinitions.txt");
	}
	
	public void removeFromOther(ActionEvent event) throws IOException {
		removeFromList(otherDef, otherText, otherList, "OtherDefinitions.txt");
	}
	//------------------------------------------------------------------------------------------
	//Resetting specific definition lists
	public void resetPlan(ActionEvent event) throws IOException {
		resetList(planDef, planText, planList, "PlanDefinitions.txt", "PlanDefinitionsDefault.txt");
	}
	
	public void resetDeliverable(ActionEvent event) throws IOException {
		resetList(deliverableDef, deliverableText, deliverableList, "DeliverableDefinitions.txt", "DeliverableDefinitionsDefault.txt");
	}
	
	public void resetInterruption(ActionEvent event) throws IOException {
		resetList(interruptionDef, interruptionText, interruptionList, "InterruptionDefinitions.txt", "InterruptionDefinitionsDefault.txt");
	}
	
	public void resetDefect(ActionEvent event) throws IOException {
		resetList(defectDef, defectText, defectList, "DefectDefinitions.txt", "DefectDefinitionsDefault.txt" );
	}
	
	public void resetOther(ActionEvent event) throws IOException {
		resetList(otherDef, otherText, otherList, "OtherDefinitions.txt", "OtherDefinitionsDefault.txt");
	}
	
}
