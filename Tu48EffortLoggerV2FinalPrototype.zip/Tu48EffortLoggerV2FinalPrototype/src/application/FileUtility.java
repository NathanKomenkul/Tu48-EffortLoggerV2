package application;

import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

import javafx.collections.ObservableList;

public class FileUtility {
	
	//Utility method for getting information from files
	public static void loadInformation(ObservableList<String> information, String fileName) throws IOException {
		FileReader fr = new FileReader(fileName);
		Scanner scanner = new Scanner(fr);
		information.clear();
		while (scanner.hasNextLine()) {
			information.add(scanner.nextLine());
		}
		scanner.close();
		fr.close();
	}
	
	//Method for writing definitions to definition text files
	public static void writeInformation(ObservableList<String> information, String fileName) throws IOException {
		FileWriter fw = new FileWriter(fileName, false);
		BufferedWriter bw = new BufferedWriter(fw);
		PrintWriter outFile = new PrintWriter(bw);	
		for (int i = 0; i < information.size(); i++) {
			outFile.printf("%s\n", information.get(i));
		}
		outFile.close();
		bw.close();
		fw.close();
	}
}
