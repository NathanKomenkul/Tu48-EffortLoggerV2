//Authorship: Patrick Hall

package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class PlanningPokerController {
	//JavaFX scene elements
	private Stage stage;
	private Scene scene;
	private Parent root;
	
	//Event of going to round one
	public void goToRoundOne(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("PlanningPokerRound1.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
		 
	//Event of going to subsequent rounds
	public void goToSubRounds(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("PlanningPokerSubsequentRounds.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	//Event of going to the finalization screen
	public void goToFinalization(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("PlanningPokerFinalization.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
			 
	//Event of going to the console
	public void goToConsole(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("Submission4Prototype.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	
}
