//Authorship: Maria Marschalik Lucan

package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class EffortLogEditorController implements Initializable{
	private Stage stage;
	private Scene scene;
	private Parent root;
	
	@FXML
	private Spinner<String> project = new Spinner<>();
	@FXML
	private Spinner<String> entry = new Spinner<>();
	@FXML
	private Spinner<String> lifeCycle = new Spinner<>();
	@FXML
	private Spinner<String> effortCategory = new Spinner<>();
	@FXML
	private Spinner<String> plan = new Spinner<>();
	
	@FXML
	private Text savedMessage;
	
	
	//Spinner<String> theProject = "Event Project";
	
	
	ObservableList<String> projectList = FXCollections.observableArrayList();
	ObservableList<String> effortCategoryList = FXCollections.observableArrayList(" ", "Plans", "Deliverables", "Interruptions", "Defects", "Others");
	ObservableList<String> planList = FXCollections.observableArrayList("Project Plan", "Risk Management Plan", "Conceptual Desing Plan", "Detailed Design Plan", "Implemetation Plan");
	ObservableList<String> lifeCycleList = FXCollections.observableArrayList();
	ObservableList<String> entryList = FXCollections.observableArrayList();
	
	
	String currProject;
	String currLifeCycle;
	String currEffortCategory;
	String currPlan;
	String currEntry;
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		try {
            FileUtility.loadInformation(projectList, "ProjectDefinitions.txt");
            FileUtility.loadInformation(lifeCycleList, "LifeCycleDefinitions.txt");
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
		//iterate through project list
		SpinnerValueFactory<String> valueFactory = new SpinnerValueFactory.ListSpinnerValueFactory<String>(projectList);
		valueFactory.setValue(projectList.get(0));
		//this.project = projectList;
		project.setValueFactory(valueFactory);
		//currProject.equals(project.getValue());
		currProject = project.getValue(); 
		
		//iterate through Effort Category list
		SpinnerValueFactory<String> valueFactoryEffort = new SpinnerValueFactory.ListSpinnerValueFactory<String>(effortCategoryList);
		valueFactoryEffort.setValue(currEffortCategory);
		effortCategory.setValueFactory(valueFactoryEffort);
		currEffortCategory = effortCategory.getValue();
		
		//iterate through plan list
		SpinnerValueFactory<String> valueFactoryPlan = new SpinnerValueFactory.ListSpinnerValueFactory<String>(planList);
		valueFactoryPlan.setValue(currPlan);
		plan.setValueFactory(valueFactoryPlan);
		currPlan = plan.getValue();
		
		//iterate through life cycle steps
		SpinnerValueFactory<String> valueFactoryStep = new SpinnerValueFactory.ListSpinnerValueFactory<String>(lifeCycleList);
		valueFactoryStep.setValue(currPlan);
		lifeCycle.setValueFactory(valueFactoryStep);
		currLifeCycle = lifeCycle.getValue();
		
		//iterate through entry list
		SpinnerValueFactory<String> valueFactoryEntry = new SpinnerValueFactory.ListSpinnerValueFactory<String>(entryList);
		valueFactoryEntry.setValue(currEntry);
		entry.setValueFactory(valueFactoryEntry);
		currEntry = entry.getValue();
	} 
	
	@FXML
	private Button clear;
	@FXML
	private Button update;
	@FXML
	private Button delete;
	@FXML
	private Button split;
	@FXML
	private Button back;
	
	
	//delete effort log entry from entry list
	@FXML
	public void deleteEntry(ActionEvent event) {
		//remove entry 
		entryList.remove(currEntry);
	}
	
	//clear current effort log entry
	@FXML
	public void clearEffortLog(ActionEvent event) {
		entryList.remove(currEntry);
		entryList.add("");	
	}
	
	//Split current effort log entry into two
	@FXML
	public void splitEntry(ActionEvent event) {
		//add duplicate to entry list
		entryList.add(currEntry);
	}
	
	//update effort log entry
	@FXML
	public void updateEntry(ActionEvent event) {
		//display text when update button is clicked
		savedMessage.setText("These attributes have been saved.");
		
		
	}
	

	
	//Return to main console
	@FXML
	public void console(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("Submission4Prototype.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}


	
}