//Authorship: Nathan Komenkul

package application;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class SceneController {
	private Stage stage;
	private Scene scene;
	private Parent root;
	private static User user;
	private static ArrayList<User> userList;
	
	//Elements of LoginScreen
	@FXML
	Label loginLabel;
	@FXML
	TextField loginID;
	@FXML
	PasswordField loginPassword;
	
	//Elements of CreateAccount
	@FXML
	Label accountLabel;
	@FXML
	TextField accountEmail;
	@FXML
	TextField accountUsername;
	@FXML
	PasswordField accountPassword;
	@FXML
	TextField accountRole;
	
	//Elements of TwoFactor
	@FXML
	Label twoFactorLabel;
	@FXML
	TextField twoFactorCode;
	
	//Number used for Two Factor Authentication
	static int secretNum = (int) (Math.random() * 999999999);
	
	//Event of going to the Login Screen
	public void goToLogin(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("LoginScreen.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	 
	//Event of going to the Account Creation Screen
	 public void goToAccountCreation(ActionEvent event) throws IOException {
		 Parent root = FXMLLoader.load(getClass().getResource("CreateAccount.fxml"));
		 stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		 scene = new Scene(root);
		 stage.setScene(scene);
		 stage.show();
	 }
	 
	 //Event of creating an account
	 public void createAccount(ActionEvent event) throws IOException {
		 String email = accountEmail.getText();
		 String username = accountUsername.getText();
		 String password = accountPassword.getText();
		 String role = accountRole.getText();
		 
		 if (email.equals("") || username.equals("") || password.equals("") || role.equals("")) {
			 accountLabel.setText("Invalid Account Creation: No fields should be empty");
			 accountLabel.setTextFill(Color.RED);
		 }
		 else {
			 //This sets up variables for writing to a Users.txt file to model an actual user database
			 FileWriter fw = new FileWriter("Users.txt", true);
			 BufferedWriter bw = new BufferedWriter(fw);
			 PrintWriter outFile = new PrintWriter(bw);
			 
			 //This creates a user object
			 user = new User(email, username, password, role);
			 
			 //This code segment appends user information to an existing Users.txt file
			 outFile.printf("%s\n%s\n%s\n%s\n", user.getEmail(), user.getUsername(), user.getPassword(), user.getRole());
			 outFile.close();
			 bw.close();
			 fw.close();
			 
			 //Text input fields are cleared
			 accountEmail.clear();
			 accountUsername.clear();
			 accountPassword.clear();
			 accountRole.clear();
			 accountLabel.setText("Account Creation Successful! Go back to login page to sign in.");
			 accountLabel.setTextFill(Color.GREEN);
		 }
	 }
	 
	 //Event of going to the Two Factor Authentication Screen
	 public void goToTwoFactor(ActionEvent event) throws IOException {
		 //Store inputs from text fields
		 String inputID = loginID.getText();
		 String inputPassword = loginPassword.getText();
		 
		 //Creation of variables for file reading and storing values
		 FileReader fr = new FileReader("Users.txt");
		 Scanner scanner = new Scanner(fr);
		 String email = "";
		 String username = "";
		 String password = "";
		 String role = "";
		 
		 //Creates a list of users
		 userList = new ArrayList<User>();
		 
		 //While loop that adds users to the list of users
		 while (scanner.hasNextLine()) {
			 email = email + scanner.nextLine();
			 username = username + scanner.nextLine();
			 password = password + scanner.nextLine();
			 role = role + scanner.nextLine();
			 user = new User(email, username, password, role);
			 userList.add(new User(email, username, password, role));
			 email = "";
			 username = "";
			 password = "";
			 role = "";
		 }
		 scanner.close();
		 
		 //Checks for all valid users
		 for (User i : userList)
		 {
			 //Checks for null users
			 if (i == null) {
				 loginLabel.setText("Invalid Username or Password. Please try again.");
				 loginLabel.setTextFill(Color.RED);
			 }
			 //Branch taken is user exists
			 else if ((inputID.equals(i.getUsername()) || inputID.equals(i.getEmail())) && inputPassword.equals(i.getPassword())) {
				 Parent root = FXMLLoader.load(getClass().getResource("TwoFactor.fxml"));
				 stage = (Stage)((Node)event.getSource()).getScene().getWindow();
				 scene = new Scene(root);
				 stage.setScene(scene);
				 stage.show();
				 System.out.println("The passcode for this login is: " + secretNum);
			 }
			 //Branch taken if input is not tied to a user
			 else {
				 loginLabel.setText("Invalid Username or Password. Please try again.");
				 loginLabel.setTextFill(Color.RED);
			 }
		 }
	 }
	 
	 //Event of going to the main console
	 public void goToConsole(ActionEvent event) throws IOException{
		 try {
			 int userPasscode = Integer.parseInt(twoFactorCode.getText());
			 
			 if (userPasscode == secretNum) {
				 Parent root = FXMLLoader.load(getClass().getResource("Submission4Prototype.fxml"));
				 stage = (Stage)((Node)event.getSource()).getScene().getWindow();
				 scene = new Scene(root);
				 stage.setScene(scene);
				 stage.show();
			 }
			 else {
				 twoFactorLabel.setText("Invalid passcode. Please try again.");
				 twoFactorLabel.setTextFill(Color.RED);
			 }
		 } catch (NumberFormatException nfe) {
			 twoFactorLabel.setText("Invalid passcode. Please try again.");
			 twoFactorLabel.setTextFill(Color.RED);
		 }
	 }
}
